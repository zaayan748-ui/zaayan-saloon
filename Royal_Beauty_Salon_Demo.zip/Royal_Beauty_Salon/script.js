const toggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');
toggle.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  toggle.setAttribute('aria-expanded', String(open));
});
nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  nav.classList.remove('open');
  toggle.setAttribute('aria-expanded', 'false');
}));

const dateInput = document.querySelector('input[name="date"]');
const today = new Date();
const localDate = new Date(today.getTime() - today.getTimezoneOffset() * 60000).toISOString().split('T')[0];
dateInput.min = localDate;

document.getElementById('booking-form').addEventListener('submit', (event) => {
  event.preventDefault();
  const data = new FormData(event.currentTarget);
  const message = [
    'Assalam-o-Alaikum Royal Beauty Salon!',
    'I would like to request an appointment.',
    `Name: ${data.get('name')}`,
    `Phone: ${data.get('phone')}`,
    `Service: ${data.get('service')}`,
    `Preferred date: ${data.get('date')}`,
    `Message: ${data.get('message') || 'None'}`
  ].join('\n');
  // Replace this demo number with the salon's real WhatsApp number.
  const whatsappNumber = '923001234567';
  window.open(`https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`, '_blank');
  document.getElementById('form-note').textContent = 'Your WhatsApp message is ready. Please press Send in WhatsApp to complete the request.';
});
