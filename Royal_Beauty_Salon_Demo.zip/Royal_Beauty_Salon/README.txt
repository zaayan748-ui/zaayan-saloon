ROYAL BEAUTY SALON — DEMO WEBSITE

HOW TO OPEN
1. Extract the ZIP file.
2. Open the folder.
3. Double-click index.html to view the website in your browser.

CUSTOMIZE BEFORE PUBLISHING
- Replace +92 300 1234567 and 923001234567 in index.html and script.js with the salon's real number.
- Update the Karachi address, service prices, text and photos.
- The booking form opens WhatsApp with the customer's details. It does not store bookings in a database.
- Google Fonts and gallery photos load from the internet, so an internet connection is needed for those assets.

Files:
- index.html: website content
- style.css: layout and design
- script.js: mobile navigation and WhatsApp booking
